
import UIKit

/// A UIButton for when the user is done creating a drawing.
public class DoneButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setTitle("Done", for: .normal)
        self.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.75)
        self.layer.cornerRadius = 4
        self.tintColor = .blue
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
