import UIKit

/// A circular button the cycles through a list of letters when tapped.
public class LetterCycleButton: ColorCycleButton {
    
    /// The label used to display the letter
    private let letterLabel = UILabel()
    
    /// The letters that the button cycles through.
    public var letters: [String] = ["G", "N", "Y"] {
        didSet {
            letterIndex = 0
            letterColorIndex = 0
            letterLabel.text = currentLetter
            letterLabel.textColor = currentLetterColor
        }
    }
    
    /// The text colors that the button cycles through.
    public var letterColors: [UIColor] = [] {
        didSet {
            letterColorIndex = letterIndex % letterColors.count
            letterLabel.textColor = currentLetterColor
        }
    }
    
    /// The current selected letter index.
    private var letterIndex = 0
    
    /// The current letter color index.
    private var letterColorIndex = 0
    
    /// The letter currently displayed by the button; the empty string if the letters array is empty.
    public var currentLetter: String {
        guard !letters.isEmpty else { return "" }
        return letters[letterIndex]
    }
    
    /// The color of the letter currently displayed by the button; black if the letter colors array is empty.
    public var currentLetterColor: UIColor {
        guard !letterColors.isEmpty else { return .black }
        return letterColors[letterColorIndex]
    }
    
    override func commonInit() {
        super.commonInit()
        
        colors = []
        
        letterLabel.translatesAutoresizingMaskIntoConstraints = false
        letterLabel.textAlignment = .center
        letterLabel.font = .systemFont(ofSize: 50, weight: .bold)
        letterLabel.textColor = .black
        addSubview(letterLabel)
        
        NSLayoutConstraint.activate([
            letterLabel.widthAnchor.constraint(equalToConstant: 80),
            letterLabel.heightAnchor.constraint(equalToConstant: 80),
            letterLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            letterLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
            ])
    }
    
    open override func cycle(_ sender: Any?) {
        super.cycle(sender)
        letterIndex = letters.isEmpty ? 0 : (letterIndex + 1) % letters.count
        letterColorIndex = letterColors.isEmpty ? 0 : (letterColorIndex + 1) % letterColors.count
        letterLabel.text = currentLetter
        letterLabel.textColor = currentLetterColor
    }
    
}
