import UIKit

/// A `CycleButton` is a circular button that cycles through its states when tapped.
open class CycleButton: UIButton {
    
    private let dimmingLayer = CALayer()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func commonInit() {
        translatesAutoresizingMaskIntoConstraints = false
        alpha = 0.9
        backgroundColor = .white
        layer.cornerRadius = 50
        layer.borderWidth = 8
        layer.borderColor = UIColor(white: 0, alpha: 0.2).cgColor
        layer.masksToBounds = true
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: 100),
            heightAnchor.constraint(equalToConstant: 100)
            ])
        
        dimmingLayer.backgroundColor = UIColor(white: 0, alpha: 0.4).cgColor
        dimmingLayer.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
        dimmingLayer.position = CGPoint(x: 50, y: 50)
        dimmingLayer.isHidden = true
        layer.addSublayer(dimmingLayer)
        
        addTarget(self, action: #selector(cycle(_:)), for: .touchUpInside)
        addTarget(self, action: #selector(dim(_:)), for: [.touchDown, .touchDragEnter])
        addTarget(self, action: #selector(undim(_:)), for: [.touchUpInside, .touchUpOutside, .touchDragExit])
    }
    
    /// Dims the button when pressed.
    @objc private func dim(_ sender: Any?) {
        dimmingLayer.isHidden = false
    }
    
    /// Undims the button when released.
    @objc private func undim(_ sender: Any?) {
        dimmingLayer.isHidden = true
    }
    
    /// Cycles the state of the button.
    @objc open func cycle(_ sender: Any?) {
        // does nothing by default
    }
    
}
