import UIKit

/// A circular button that cycles through a list of colors when tapped.
open class ColorCycleButton: CycleButton {
    
    /// The colors that the button cycles through.
    public var colors: [UIColor] = [#colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0), #colorLiteral(red: 0.21960784494876862, green: 0.007843137718737125, blue: 0.8549019694328308, alpha: 1.0), #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0), #colorLiteral(red: 0.9372549057006836, green: 0.3490196168422699, blue: 0.1921568661928177, alpha: 1.0), #colorLiteral(red: 0.9607843160629272, green: 0.7058823704719543, blue: 0.20000000298023224, alpha: 1.0), #colorLiteral(red: 0.46666666865348816, green: 0.7647058963775635, blue: 0.2666666805744171, alpha: 1.0)] {
        didSet {
            colorIndex = 0
            backgroundColor = currentColor
        }
    }
    
    /// The current selected color index.
    private var colorIndex = 0
    
    /// The color currently displayed by the button; white if the colors array is empty.
    public var currentColor: UIColor {
        guard !colors.isEmpty else { return .white }
        return colors[colorIndex]
    }
    
    open override func cycle(_ sender: Any?) {
        colorIndex = colors.isEmpty ? 0 : (colorIndex + 1) % colors.count
        backgroundColor = currentColor
    }
}
