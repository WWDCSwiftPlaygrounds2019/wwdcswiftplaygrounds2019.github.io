//#-hidden-code
//#-code-completion(everything, hide)
import UIKit
import PlaygroundSupport
import Vision
import AVKit

PlaygroundPage.current.liveView = SecondaryViewController()
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
/*:
 Now that there's a drawing for each letter, you can switch between them by signing 'G', 'N', and 'Y' in American Sign Language. Try it out by tapping Run My Code!
 */

