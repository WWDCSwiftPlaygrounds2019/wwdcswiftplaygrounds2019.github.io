//#-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, array, color, image)
//#-code-completion(identifier, show, setColors(colors:))
import UIKit
import PlaygroundSupport
import Vision
import AVKit

let vc = ViewController()
PlaygroundPage.current.liveView = vc
PlaygroundPage.current.needsIndefiniteExecution = true

func setColors(colors: [UIColor]) {
    vc.setColors(colors: colors)
}
//#-end-hidden-code
/*:
Welcome to Sign Me Up!, a playground written for WWDC 2019.

To begin, call the `setColors` function and include whatever colors you want to draw with.

Then, tap Run My Code.

In the live view, you can select a letter and create a drawing on your face! When you're done, tap 'Save'. This book supports the letters G, N, and Y. Make a drawing for all three of them before you move on!
*/

