// File to hold the masks drawn by the user.

import UIKit
import Foundation
import PlaygroundSupport

enum SupportedLetter {
    case G
    case Y
    case N
}

fileprivate extension SupportedLetter {
    var keyValueStoreKey: String {
        switch self {
        case .G:
            return "G"
        case .N:
            return "N"
        case .Y:
            return "Y"
        }
    }
}

func getMask(letter: SupportedLetter) -> [[pointOnFace]] {
    let dataValue = PlaygroundKeyValueStore.current[letter.keyValueStoreKey]
    if case let .data(data)? = dataValue {
        let decoder = PropertyListDecoder()
        do {
            return try decoder.decode(Array<Array<pointOnFace>>.self, from: data)
        }
        catch {
            // Don't do anything special on error. Just return an empty list.
            return []
        }
    }
    else {
        return []
    }
}

func setMask(letter: SupportedLetter, points: [[pointOnFace]]) {
    let encoder = PropertyListEncoder()
    encoder.outputFormat = .binary
    do {
        let data = try encoder.encode(points)
        PlaygroundKeyValueStore.current[letter.keyValueStoreKey] = .data(data)
    }
    catch {
        fatalError("Unable to serialize face points: \(error)")
    }
}
