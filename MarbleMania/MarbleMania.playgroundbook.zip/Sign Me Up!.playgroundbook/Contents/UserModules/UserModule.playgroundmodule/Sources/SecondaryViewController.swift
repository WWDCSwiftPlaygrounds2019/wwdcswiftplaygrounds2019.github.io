import UIKit
import AVFoundation
import CoreML
import Vision
import CameraControls

/// A class to get camera input and track facial landmarks as well as recognize the signs for G, Y, and N in live capture.
public class SecondaryViewController: UIViewController {
    let session = AVCaptureSession()
    var previewLayer: AVCaptureVideoPreviewLayer!
    let dataOutputQueue = DispatchQueue(
        label: "video data queue",
        qos: .userInitiated,
        attributes: [],
        autoreleaseFrequency: .workItem
    )

    var faceView: FaceView!

    var sequenceHandler = VNSequenceRequestHandler()

    var model: VNCoreMLModel!

    public override func viewDidLoad() {
        super.viewDidLoad()
        faceView = FaceView(frame: self.view.bounds)
        faceView.alpha = 1
        faceView.backgroundColor = .clear
        faceView.clearsContextBeforeDrawing = true

        configureCaptureSession()

        view.addSubview(faceView)

        // Create a CoreML model used for Vision requests.
        do {
            model = try VNCoreMLModel(for: MLModel(contentsOf: #fileLiteral(resourceName: "Handsx.mlmodelc")))
        } catch {
            fatalError()
        }

        session.startRunning()
    }
}

extension SecondaryViewController {
    func configureCaptureSession(){
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            fatalError("no cam")
        }

        do {
            let camInput = try AVCaptureDeviceInput(device: camera)
            session.addInput(camInput)
        } catch {
            print("nope")
        }

        let vidOutput = AVCaptureVideoDataOutput()
        vidOutput.setSampleBufferDelegate(self, queue: dataOutputQueue)
        vidOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        let captureConnection = vidOutput.connection(with: .video)
        captureConnection?.isEnabled = true

        session.addOutput(vidOutput)

        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.connection?.videoOrientation = .landscapeRight
        previewLayer.videoGravity = .resizeAspectFill

        previewLayer.frame = view.bounds

        view.layer.insertSublayer(previewLayer, at: 0)
    }
}

extension SecondaryViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }

        // Create a request to detect faces and their landmarks.
        let detectFaceRequest = VNDetectFaceLandmarksRequest(completionHandler: detectedFace)

        // Create a request to recognize sign language.
        var visionRequest: VNCoreMLRequest? = nil
        do {
            let objectRecognition = VNCoreMLRequest(model: model, completionHandler: { (request, error) in
                DispatchQueue.main.async(execute: {
                    if let results = request.results {
                        if #available(iOSApplicationExtension 12.0, *) {
                            self.detectedHand(request: request, error: error)
                        }
                    }
                })
            })
            visionRequest = objectRecognition
        } catch {
            print("Something went wrong!")
        }

        do {
            try sequenceHandler.perform(
                [detectFaceRequest, visionRequest!],
                on: imageBuffer,
                orientation: .downMirrored
            )

        } catch {
            print("Sequence Handler was unable to perform the detectFace and vision requests.")
        }
    }
}

@available(iOSApplicationExtension 12.0, *)
extension SecondaryViewController {
    func detectedHand(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNRecognizedObjectObservation], let result = results.first else { return }
        updateHandView(for: result)
    }

    func updateHandView(for result: VNRecognizedObjectObservation) {
        if result.confidence > 0.15 {
            if result.labels[0].identifier == "G" {
                let mask = getMask(letter: .G)
                faceView.changeMask(mask: mask)
            } else if result.labels[0].identifier == "N" {
                let mask = getMask(letter: .N)
                faceView.changeMask(mask: mask)
            } else if result.labels[0].identifier == "Y" {
                let mask = getMask(letter: .Y)
                faceView.changeMask(mask: mask)
            }
        }
    }
}

extension SecondaryViewController {
    func detectedFace(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNFaceObservation], let result = results.first else {
            faceView.clear()
            return
        }
        updateFaceView(for: result)
    }

    func landmark(point: CGPoint, to rect: CGRect) -> CGPoint {
        let absolutePoint = point.absolutePoint(in: rect)
        let converted = previewLayer.layerPointConverted(fromCaptureDevicePoint: absolutePoint)
        return converted
    }

    func landmark(points: [CGPoint]?, to rect: CGRect) -> [CGPoint]? {
        return points?.compactMap { landmark(point: $0, to: rect) }
    }

    func updateFaceView(for result: VNFaceObservation) {
        defer {
            DispatchQueue.main.async {
                self.faceView.setNeedsDisplay()
            }
        }

        let box = result.boundingBox
        faceView.boundingBox = previewLayer.layerRectConverted(fromMetadataOutputRect: box)

        guard let landmarks = result.landmarks else {
            return
        }

        if let leftPupil = landmark(points: landmarks.leftPupil?.normalizedPoints, to: result.boundingBox) {
            faceView.leftPupil = leftPupil
        }
    }
}
