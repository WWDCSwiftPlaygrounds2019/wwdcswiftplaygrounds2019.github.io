
import UIKit
import Vision

struct Color: Codable {
    var red: CGFloat = 0.0
    var green: CGFloat = 0.0
    var blue: CGFloat = 0.0
    var alpha: CGFloat = 0.0

    var uiColor: UIColor {
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }

    init(color: UIColor) {
        color.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
    }
}

struct pointOnFace: Codable {
    var xDistanceToLeftPupil: CGFloat
    var yDistanceToLeftPupil: CGFloat
    var color: Color
}

class FaceView: UIView {
    var boundingBox = CGRect.zero

    var leftPupil: [CGPoint] = []

    var allTranslatedPointsFromLeftPupil: [[pointOnFace]] = [[]]

    func lineEnded() {
        allTranslatedPointsFromLeftPupil.append([])
    }

    func newPointAdded(point: CGPoint, color: Color) {
        guard let leftP = leftPupil.first else {
            return
        }
        let pupilTranslatedPoint = pointOnFace(xDistanceToLeftPupil: point.x - leftP.x, yDistanceToLeftPupil: point.y - leftP.y, color: color)

        allTranslatedPointsFromLeftPupil[allTranslatedPointsFromLeftPupil.count - 1].append(pupilTranslatedPoint)
    }

    func clear() {
        boundingBox = .zero

        DispatchQueue.main.async {
            self.setNeedsDisplay()
        }
    }

    func doneWithMask() {
        boundingBox = .zero
        allTranslatedPointsFromLeftPupil = [[]]

        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }

        DispatchQueue.main.async {
            self.setNeedsDisplay()
        }
    }

    func changeMask(mask: [[pointOnFace]]) {
        allTranslatedPointsFromLeftPupil = mask
    }

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        context.saveGState()
        defer {
            context.restoreGState()
        }

        context.addRect(boundingBox)
        UIColor.red.setStroke()
        context.strokePath()

        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        context.setLineJoin(.round)
        context.setMiterLimit(2.0)

        UIColor.white.setStroke()

        guard !allTranslatedPointsFromLeftPupil.isEmpty else { return }

        if !allTranslatedPointsFromLeftPupil[0].isEmpty {
            context.setLineWidth(7)
            context.setLineCap(.round)
            var pointsToDraw: [[CGPoint]] = [[]]

            for line in allTranslatedPointsFromLeftPupil {
                if !line.isEmpty {
                    line[0].color.uiColor.setStroke()
                    pointsToDraw.append([])
                    for (index, point) in line.enumerated() {
                        var newPoint = CGPoint(x: leftPupil.first!.x + line[index].xDistanceToLeftPupil, y: leftPupil.first!.y + line[index].yDistanceToLeftPupil)
                        pointsToDraw[pointsToDraw.count - 1].append(newPoint)
                    }
                    context.addLines(between: pointsToDraw[pointsToDraw.count - 1])
                    context.strokePath()
                }
            }
        }
    }
}
