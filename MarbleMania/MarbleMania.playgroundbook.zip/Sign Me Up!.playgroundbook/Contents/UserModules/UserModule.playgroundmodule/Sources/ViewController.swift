import UIKit
import AVFoundation
import Vision
import CameraControls
import UISetup

/// Use AVFoundation to get camera input and display it, and then allow users to create drawings that track to their face using the Vision framework.
public class ViewController: UIViewController {
    // Set up AV work for camera input.
    let session = AVCaptureSession()
    var previewLayer: AVCaptureVideoPreviewLayer!
    let dataOutputQueue = DispatchQueue(
        label: "video data queue",
        qos: .userInitiated,
        attributes: [],
        autoreleaseFrequency: .workItem
    )

    // A custom view to hold drawings and facial landmarks.
    var faceView: FaceView!

    // An object to process Vision requests.
    var sequenceHandler = VNSequenceRequestHandler()

    // UI objects to allow users to set letters, colors, and save drawings.
    var doneButton: DoneButton!
    var letterButton: LetterCycleButton!
    var colorButton: ColorCycleButton!

    public override func viewDidLoad() {
        super.viewDidLoad()

        // Set up the FaceView.
        faceView = FaceView(frame: self.view.bounds)
        faceView.alpha = 1
        faceView.backgroundColor = .clear
        faceView.clearsContextBeforeDrawing = true

        // Set up the AVCapture work.
        configureCaptureSession()

        // Set up UI.
        doneButton = DoneButton()
        doneButton.addTarget(self, action: #selector(saveMask), for: .touchUpInside)

        letterButton = LetterCycleButton()
        letterButton.letters = ["Y", "N", "G"]

        colorButton = ColorCycleButton()

        view.addSubview(faceView)
        view.addSubview(doneButton)
        view.addSubview(letterButton)
        view.addSubview(colorButton)
        NSLayoutConstraint.activate([
            colorButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            colorButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -40),
            letterButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            letterButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -40),
            doneButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            doneButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -65), doneButton.widthAnchor.constraint(equalToConstant: 80.0),
            doneButton.heightAnchor.constraint(equalToConstant: 40.0)
            ])

        // Start video capture!
        session.startRunning()
    }
}

extension ViewController {
    @objc func saveMask() {
        let nameSign = letterButton.currentLetter

        if nameSign == "G" {
            setMask(letter: .G, points: faceView.allTranslatedPointsFromLeftPupil)
        } else if nameSign == "N" {
            setMask(letter: .N, points: faceView.allTranslatedPointsFromLeftPupil)
        } else if nameSign == "Y" {
            setMask(letter: .Y, points: faceView.allTranslatedPointsFromLeftPupil)
        } else {
            fatalError("No support for recognizing letters other than G, N, and Y.")
        }

        faceView.doneWithMask()
    }
}

extension ViewController {
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }

        guard !doneButton.frame.contains(touch.location(in: view)) && !letterButton.frame.contains(touch.location(in: view)) && !colorButton.frame.contains(touch.location(in: view)) else {
            return
        }

        defer {
            DispatchQueue.main.async {
                self.faceView.setNeedsDisplay()
            }
        }

        let codableColor = Color(color: colorButton.currentColor)
        faceView.newPointAdded(point: touch.location(in: view), color: codableColor)
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let currentTouch = touches.first!.location(in: view)

        guard !doneButton.frame.contains(currentTouch) && !letterButton.frame.contains(currentTouch) && !colorButton.frame.contains(currentTouch) else {
            return
        }

        let codableColor = Color(color: colorButton.currentColor)
        faceView.newPointAdded(point: currentTouch, color: codableColor)
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let currentTouch = touches.first!.location(in: view)

        guard !doneButton.frame.contains(currentTouch) && !letterButton.frame.contains(currentTouch) && !colorButton.frame.contains(currentTouch) else {
            return
        }

        let codableColor = Color(color: colorButton.currentColor)
        faceView.newPointAdded(point: currentTouch, color: codableColor)
        faceView.lineEnded()
    }
}

extension ViewController {
    func configureCaptureSession(){
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            fatalError("There is no camera available.")
        }

        do {
            let camInput = try AVCaptureDeviceInput(device: camera)
            session.addInput(camInput)
        } catch {
            fatalError("There is no camera available for input.")
        }

        let vidOutput = AVCaptureVideoDataOutput()
        vidOutput.setSampleBufferDelegate(self, queue: dataOutputQueue)
        vidOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        let captureConnection = vidOutput.connection(with: .video)
        captureConnection?.isEnabled = true

        session.addOutput(vidOutput)

        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.connection?.videoOrientation = .landscapeRight
        previewLayer.videoGravity = .resizeAspectFill

        previewLayer.frame = view.bounds

        view.layer.insertSublayer(previewLayer, at: 0)
    }
}

extension ViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }

        // An image analysis request that finds facial features in an image.
        let detectFaceRequest = VNDetectFaceLandmarksRequest(completionHandler: detectedFace)

        do {
            try sequenceHandler.perform(
                [detectFaceRequest],
                on: imageBuffer,
                orientation: .downMirrored
            )

        } catch {
            print("error")
        }
    }
}

extension ViewController {
    func detectedFace(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNFaceObservation], let result = results.first else {
            faceView.clear()
            return
        }
        updateFaceView(for: result)
    }

    func landmark(point: CGPoint, to rect: CGRect) -> CGPoint {
        let absolutePoint = point.absolutePoint(in: rect)
        let convertedPoint = previewLayer.layerPointConverted(fromCaptureDevicePoint: absolutePoint)
        return convertedPoint
    }

    func landmark(points: [CGPoint]?, to rect: CGRect) -> [CGPoint]? {
        return points?.compactMap { landmark(point: $0, to: rect) }
    }

    func updateFaceView(for result: VNFaceObservation) {
        defer {
            DispatchQueue.main.async {
                self.faceView.setNeedsDisplay()
            }
        }

        let box = result.boundingBox
        faceView.boundingBox = previewLayer.layerRectConverted(fromMetadataOutputRect: box)

        guard let landmarks = result.landmarks else {
            return
        }

        if let leftPupil = landmark(points: landmarks.leftPupil?.normalizedPoints, to: result.boundingBox) {
            faceView.leftPupil = leftPupil
        }
    }
}

extension ViewController {
    public func setColors(colors: [UIColor]) {
        colorButton.colors = colors
    }
}

extension CGPoint {
    func absolutePoint(in rect: CGRect) -> CGPoint {
        let ogPoint = CGPoint(x: x * rect.size.width, y: y * rect.size.height)
        return CGPoint(x: ogPoint.x + rect.origin.x, y: ogPoint.y + rect.origin.y)
    }
}



