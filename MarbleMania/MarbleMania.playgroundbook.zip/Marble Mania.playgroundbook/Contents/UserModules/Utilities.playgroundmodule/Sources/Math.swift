import Foundation
import CoreGraphics

/// Returns a function that will smooth input over the given number of samples.
public func hysteresis(initial: Double = 0, samples: Int) -> (Double) -> (Double) {
    var history: Double = initial
    let samples = Double(samples)
    return { value in
        history = (history * samples + value) / (samples + 1)
        return history
    }
}

public extension CGFloat {
    /// Clamps the value within the given range.
    func clamped(between: Range<CGFloat>) -> CGFloat {
        return Swift.min(Swift.max(self, between.lowerBound), between.upperBound)
    }
}

public extension CGVector {
    /// Clamps both components of the vector to the given absolute value.
    mutating func clamp(absoluteValueOf absoluteValue: CGFloat) {
        self.dx = dx.clamped(between: -absoluteValue..<absoluteValue)
        self.dy = dy.clamped(between: -absoluteValue..<absoluteValue)
    }
    
    /// Returns a new vector with the components clamped to the absolute value.
    func clamped(absoluteValueOf absoluteValue: CGFloat) -> CGVector {
        var next = self
        next.clamp(absoluteValueOf: absoluteValue)
        return next
    }
}
