import CoreMotion
import CoreGraphics
import Utilities

/// An analogous value to the `CoreMotion` `CMAcceleration` type, but it uses `CGFloat` instead of `Double` for better integration throughout the game code.
public struct Acceleration {
    public var x: CGFloat = 0
    public var y: CGFloat = 0
    public var z: CGFloat = 0
}

/// This is a wrapper class around `CMMotionManager` to make it simpler to access the instantaneous value of the accelerometer without dealing with the optional `accelerometerData` property.
public final class Accelerometer {
    private let manager: CMMotionManager
    
    public var acceleration: Acceleration {
        guard let data = manager.accelerometerData else { return Acceleration() }
        return Acceleration(x: CGFloat(data.acceleration.x),
                            y: CGFloat(data.acceleration.y),
                            z: CGFloat(data.acceleration.z))
    }
    
    public init() {
        manager = CMMotionManager()
        manager.accelerometerUpdateInterval = 0.01
        manager.startAccelerometerUpdates()
    }
}
