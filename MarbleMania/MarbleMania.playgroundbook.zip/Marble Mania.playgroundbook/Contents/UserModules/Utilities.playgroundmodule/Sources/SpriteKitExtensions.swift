import SpriteKit

public extension SKNode {
    /// Similar to the `convert(_,to:)` method for `CGPoint`, this method will convert a `CGRect` from the receiver's coordinates to the given node's coordinates.
    func convert(_ rect: CGRect, to node: SKNode) -> CGRect {
        let topLeft = rect.origin
        let bottomRight = CGPoint(x: rect.maxX, y: rect.maxY)
        let convertedTopLeft = convert(topLeft, to: node)
        let convertedBottomRight = convert(bottomRight, to: node)
        return CGRect(x: convertedTopLeft.x, y: convertedTopLeft.y, width: convertedBottomRight.x - convertedTopLeft.x, height: convertedBottomRight.y - convertedTopLeft.x)
    }
}
