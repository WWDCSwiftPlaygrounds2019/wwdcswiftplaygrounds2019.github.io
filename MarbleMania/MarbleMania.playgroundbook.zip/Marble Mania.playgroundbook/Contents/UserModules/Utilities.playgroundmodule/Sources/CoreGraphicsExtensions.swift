import CoreGraphics

public extension CGRect {
    /// Returns the center poing of the `CGRect`.
    var center: CGPoint {
        get {
            return CGPoint(x: midX, y: midY)
        }
        set {
            origin = CGPoint(x: newValue.x - width/2, y: newValue.y - height/2)
        }
    }
    
    /// Creates a `CGRect` with the given center and size.
    init(center: CGPoint, size: CGSize) {
        var rect = CGRect(origin: .zero, size: size)
        rect.center = center
        self = rect
    }
}
