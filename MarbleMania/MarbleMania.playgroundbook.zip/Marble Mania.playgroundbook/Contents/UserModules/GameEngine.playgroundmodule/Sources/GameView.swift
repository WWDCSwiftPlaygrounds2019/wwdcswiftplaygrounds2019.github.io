import SpriteKit

var debugOverlayOn = false

public final class GameView: SKView {
    public override init(frame: CGRect) {
                super.init(frame: frame)
        let scene = GameScene(size: .zero)
        presentScene(scene)
        
        if debugOverlayOn {
            showsPhysics = true
            showsFPS = true
            showsNodeCount = true
        }
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
        addGestureRecognizer(tap)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func viewTapped() {
        guard let scene = scene as? GameScene else { return }
        guard !scene.gameState.isRunning else { return }
        let newScene = GameScene(size: bounds.size)
        presentScene(newScene, transition: .crossFade(withDuration: 0.2))
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
        scene?.size = bounds.size
    }
}
