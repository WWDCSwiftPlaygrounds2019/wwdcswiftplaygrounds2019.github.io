import SpriteKit
import GameModel
import Utilities

public final class GameScene: SKScene {
    private let accelerometer = Accelerometer()
    
    private let mapNode: MapNode
    
    private let marble: MarbleNode
    
    private let baseWallTop: WallLayer
    private let baseWallBottom: WallLayer
    
    private let parallaxWallBottom: WallLayer
    private let parallaxWallTop: WallLayer
    
    private let collisionDetector = HoleCollisionDetector()
    
    private var scoreCalculator = ScoreCalculator()
    private let scoreLabel = SKLabelNode()
    
    public private(set) var gameState: GameState = .active
    
    public override init(size: CGSize) {
        mapNode = MapNode()
        marble = MarbleNode.make()
        
        let normalBrickSize = CGSize(width: 70, height: 70)
        baseWallTop = WallLayer(brickSize: normalBrickSize, withPhysics: true, inverted: true)
        baseWallBottom = WallLayer(brickSize: normalBrickSize, withPhysics: true, inverted: false)
        
        let parallaxBrickSize = CGSize(width: 120, height: 120)
        parallaxWallBottom = WallLayer(brickSize: parallaxBrickSize, withPhysics: false, inverted: false)
        parallaxWallTop = WallLayer(brickSize: parallaxBrickSize, withPhysics: false, inverted: true)
        
        super.init(size: size)
        
        let camera = SKCameraNode()
        self.camera = camera
        addChild(camera)
        
        addChild(mapNode)
        
        addChild(baseWallTop)
        addChild(baseWallBottom)
        addChild(parallaxWallBottom)
        addChild(parallaxWallTop)
        
        scoreLabel.horizontalAlignmentMode = .left
        scoreLabel.zPosition = 100
        scoreLabel.fontName = "San Fransisco Bold"
        camera.addChild(scoreLabel)
        
        marble.position = CGPoint(x: 100, y: 150)
        addChild(marble)
        
        backgroundColor = UIColor(white: 0.8, alpha: 1)
        
        physicsWorld.contactDelegate = collisionDetector
        collisionDetector.collisionCallback = { [weak self] hole, marble in
            self?.endGame(hole: hole, marble: marble)
        }
        
        // Call this here to re-use our layout logic once the scene is initialized.
        didChangeSize(.zero)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func update(_ currentTime: TimeInterval) {
        switch gameState {
        case .active:
            applyForceToMarble(marble: marble, acceleration: accelerometer.acceleration)
            let x = camera!.position.x
            let newScore = scoreCalculator.updateScore(withDistance: x, time: currentTime)
            scoreLabel.text = "Score: \(scoreFormatter.string(from: newScore as NSNumber) ?? "<nil>")"
        case .ended:
            // Nothing to do. We're showing the failure mode.
            break
        }
    }
    
    public override func didSimulatePhysics() {
        if gameState.isRunning {
            clampMarbleVelocity(marble: marble)
        }
        updateCameraPositionBasedOnMarble()
    }
    
    public override func didChangeSize(_ oldSize: CGSize) {
        // Don't do any work if the size is the same as we've seen before
        guard size != oldSize else { return }
        mapNode.position = CGPoint(x: 0, y: size.height/2)
        
        // And move the dot to the center because we don't want it to be off screen
        marble.position = CGPoint(x: camera?.position.x ?? size.width/2, y: size.height/2)
        
        // Add edge boundaries
        let edge = SKPhysicsBody(edgeLoopFrom: CGRect(x: 0, y: 0, width: 500000000, height: size.height))
        self.physicsBody = edge
        
        // Position the stationary walls. The parallax walls are updated in the game loop.
        baseWallTop.position = CGPoint(x: 0, y: size.height - baseWallBottom.brickSize.height/2)
        baseWallBottom.position = CGPoint(x: 0, y: baseWallBottom.brickSize.height/2)
        
        scoreLabel.position = CGPoint(x: -(size.width/2) + 10, y: (size.height/2) - 50)
    }
}

extension GameScene {
    func endGame(hole: HoleNode, marble: MarbleNode) {
        guard gameState.isRunning else {
            fatalError("Can only end game if it was running. \(gameState)")
        }
        // Disable the marble body so it can "sink" into the hole
        marble.physicsBody?.velocity = .zero
        marble.physicsBody?.angularVelocity = 0
        marble.physicsBody?.isDynamic = false
        // Sink the marble!
        let holeCenter = hole.convert(position, to: marble.parent!)
        marble.run(.group([
            .move(to: holeCenter, duration: 0.1),
            .scale(by: 0, duration: 0.3),
            ]))
        self.gameState = .ended
    }
    
    func updateCameraPositionBasedOnMarble() {
        let cameraX: CGFloat = max(marble.position.x, size.width/2)
        let cameraPosition = CGPoint(x: cameraX, y: size.height/2)
        camera?.position = cameraPosition
        let rect = CGRect(center: cameraPosition, size: size)
        
        baseWallTop.render(in: rect)
        
        baseWallBottom.render(in: rect)
        
        // Figure out the parallax effect
        let parallaxAdjustmentX: CGFloat = (cameraPosition.x - size.width/2) * 0.2
        let parallaxAdjustmentY: CGFloat = accelerometer.acceleration.x * -10
        
        parallaxWallBottom.position = CGPoint(x: baseWallBottom.position.x - parallaxAdjustmentX, y: parallaxWallBottom.brickSize.height/2 - parallaxAdjustmentY - 10)
        parallaxWallBottom.render(in: convert(rect, to: parallaxWallBottom))
        parallaxWallTop.position = CGPoint(x: baseWallTop.position.x - parallaxAdjustmentX, y: size.height - parallaxWallBottom.brickSize.height/2 - parallaxAdjustmentY + 10)
        parallaxWallTop.render(in: convert(rect, to: parallaxWallTop))
        
        mapNode.render(in: rect.inset(by: UIEdgeInsets(top: baseWallTop.brickSize.height, left: 0, bottom: baseWallBottom.brickSize.height, right: 0)))
    }
}

private let scoreFormatter: NumberFormatter = {
    let n = NumberFormatter()
    n.usesGroupingSeparator = true
    return n
}()
