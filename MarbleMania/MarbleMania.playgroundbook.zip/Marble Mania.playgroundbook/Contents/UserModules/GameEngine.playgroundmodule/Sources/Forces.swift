import SpriteKit
import Utilities

/// Clamps the maximum velocity of the marble to a value that makes sense within the game.
func clampMarbleVelocity(marble: MarbleNode) {
    let maxValue: CGFloat = 800
    marble.physicsBody?.velocity.clamp(absoluteValueOf: maxValue)
}

/// Applies the given `Acceleration` value to the `MarbleNode` based on calculations that make sense within the game.
func applyForceToMarble(marble: MarbleNode, acceleration: Acceleration) {
    let multiplier: CGFloat = 600
    let gravity = CGVector(dx: -acceleration.y * multiplier,
                           dy: acceleration.x * multiplier)
    marble.physicsBody?.applyForce(gravity)
}
