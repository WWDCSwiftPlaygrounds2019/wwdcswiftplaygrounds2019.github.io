import SpriteKit

class HoleCollisionDetector: NSObject, SKPhysicsContactDelegate {
    var collisionCallback: (HoleNode, MarbleNode) -> () = {_, _ in}
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB
        guard let hole = bodyA.node as? HoleNode ?? bodyB.node as? HoleNode else { return }
        guard let marble = bodyA.node as? MarbleNode ?? bodyB.node as? MarbleNode else { return }
        collisionCallback(hole, marble)
    }
}
