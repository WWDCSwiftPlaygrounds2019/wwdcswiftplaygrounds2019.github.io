import SpriteKit
import GameModel

/// A node that lays out holes based on the underlying `Map` across the game coordinate space.
public class MapNode: SKNode {
    
    public init(map: Map = Map()) {
        self.map = map
        super.init()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// The underlying `Map` model that describes how holes are laid out in columns.
    var map: Map
    
    /// Hole nodes mapped from column indexes
    var holeNodes: [Int: HoleNode] = [:]
    
    /// An internal queue for hole nodes that were used previously but are no longer needed on screen. These get reused similar to the way `UITableViewCell` instances get reused.
    private var reuseQueue: [HoleNode] = []
    
    /// Positions hole nodes as necessary within the given `rect`. This will create enough hole nodes as necessary to show within the rectangle, moving old nodes into the `reuseQueue` if they aren't needed, and pulling them out of the queue once they become needed.
    ///
    /// This is expected to be called within the game loop as the user rolls the marble down the trench.
    func render(in rect: CGRect) {
        var visibleHeight = rect.height - map.holeSize.height
        let currentColumnSet = Set(holeNodes.keys)
        let nextColumnSet = map.columnIndexes(in: rect)
        let columnsToRemove = currentColumnSet.subtracting(nextColumnSet)
        for columnIndex in columnsToRemove {
            guard let node = holeNodes[columnIndex] else { continue }
            node.position = CGPoint(x: -5000, y: -5000)
            reuseQueue.append(node)
            holeNodes.removeValue(forKey: columnIndex)
        }
        let columnsToAdd = nextColumnSet.subtracting(currentColumnSet)
        for columnIndex in columnsToAdd {
            let mapColumn = map.getColumn(at: columnIndex, currentHeight: visibleHeight)
            guard let hole = mapColumn.hole else { continue }
            let node = reuseQueue.popLast() ?? {
                let n = HoleNode.make(size: map.holeSize)
                addChild(n)
                return n
                }()
            holeNodes[columnIndex] = node
        }
        for (columnIndex, holeNode) in holeNodes {
            let mapColumn = map.getColumn(at: columnIndex, currentHeight: visibleHeight)
            guard let hole = mapColumn.hole else { continue }
            holeNode.position = CGPoint(x: hole.x, y: hole.yOffset)
            holeNode.size = map.holeSize
        }
    }
}

public extension MapNode {
    /// This function returns an `SKView` with this `MapNode` rendered inside at the given `rect` to help debug placement of holes within the map.
    func preview(rect: CGRect) -> UIView {
        let view = SKView(frame: CGRect(x: 0, y: 0, width: rect.width, height: rect.height))
        let scene = SKScene()
        scene.size = rect.size
        scene.anchorPoint = CGPoint(x: 0.0, y: 0.5)
        scene.backgroundColor = .white
        view.presentScene(scene)
        scene.addChild(self)
        render(in: rect)
        self.position = CGPoint(x: -rect.origin.x, y: 0)
        view.setNeedsDisplay()
        view.setNeedsLayout()
        view.draw(view.bounds)
        return view
    }
}
