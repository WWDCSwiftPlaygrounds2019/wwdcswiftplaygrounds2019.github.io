import SpriteKit

private let boundaryTexture = SKTexture(image: #imageLiteral(resourceName: "crate1@2x.png"))
private let floatingTexture = SKTexture(image: #imageLiteral(resourceName: "platform1@2x.png"))

/// A node representing a tile in a wall layer.
class WallNode: SKSpriteNode {
    /// Creates a `WallNode` configured with the given size and physical characteristics.
    ///
    /// - parameter brickSize: The size of the wall brick.
    /// - parameter withPhysics: If `true`, then this brick will have an `SKPhysicsBody` and participate in the physics simulation with the marble.
    ///
    /// - note: The texture type changes depending on the value of `withPhysics` to either be the solid wall texture the marble can collide with, or the green floating texture that is a parallax effect layered on top of the main wall.
    class func make(brickSize: CGSize, withPhysics: Bool) -> WallNode {
        let wall: WallNode
        if withPhysics {
            wall = WallNode(texture: boundaryTexture, color: .clear, size: brickSize)
            let body = SKPhysicsBody(rectangleOf: brickSize)
            body.affectedByGravity = false
            body.isDynamic = false
            wall.physicsBody = body
        }
        else {
            // The textures have a 1px border, so adjust the width to avoid that showing up when laying out.
            let adjustedSize = CGSize(width: brickSize.width+4, height: brickSize.height)
            wall = WallNode(texture: floatingTexture, color: .clear, size: adjustedSize)
        }
        return wall
    }
}
