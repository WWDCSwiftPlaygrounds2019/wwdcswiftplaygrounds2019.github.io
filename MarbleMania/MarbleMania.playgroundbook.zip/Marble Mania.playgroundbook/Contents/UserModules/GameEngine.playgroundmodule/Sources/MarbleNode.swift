import SpriteKit

class MarbleNode: SKSpriteNode {
    class func make() -> MarbleNode {
        let texture = SKTexture(image: #imageLiteral(resourceName: "bumper3@2x.png"))
        let marble = MarbleNode(texture: texture, color: .clear, size: CGSize(width: 40, height: 40))
        let body = SKPhysicsBody(circleOfRadius: 20)
        body.restitution = 0.5
        body.affectedByGravity = false
        body.allowsRotation = true
        body.mass = 0.3
        body.contactTestBitMask = 1
        marble.physicsBody = body
        return marble
    }
}
