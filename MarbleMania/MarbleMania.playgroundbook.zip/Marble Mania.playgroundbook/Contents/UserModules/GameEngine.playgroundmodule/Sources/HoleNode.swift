import SpriteKit

class HoleNode: SKSpriteNode {
    public static func make(size: CGSize) -> HoleNode {
        let texture = SKTexture(image: #imageLiteral(resourceName: "Hole Texture.png"))
        let node = HoleNode(texture: texture, color: .clear, size: size)
        let radius: CGFloat = (size.width/2 * 0.8)
        let body = SKPhysicsBody(circleOfRadius: radius)
        body.isDynamic = false
        body.categoryBitMask = 1
        node.physicsBody = body
        return node
    }
}

