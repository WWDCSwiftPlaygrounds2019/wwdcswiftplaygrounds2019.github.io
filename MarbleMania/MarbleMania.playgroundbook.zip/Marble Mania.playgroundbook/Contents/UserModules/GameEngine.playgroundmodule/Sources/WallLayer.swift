import SpriteKit

/// Lays out a single layer of bricks to act as a "wall" for the trench. If the layer is initialized with `withPhysics` set to `false`, then the layer will not collide with the marble.
class WallLayer: SKNode {
    /// The size of the bricks laid out and managed by this layer.
    let brickSize: CGSize
    
    /// If `true`, then the bricks participate in the physics simulation and the marble can collide with them.
    let withPhysics: Bool
    
    /// If `true`, then the bricks in this layer are flipped vertically. This is useful to have two similar layers with the same textures act as the top and bottom of the trench.
    let inverted: Bool
    
    /// An internal reuse queue for brick nodes that aren't currently needed in the viewport.
    private var reuseQueue: [SKNode] = []
    
    /// An internal dictionary mapping column indexes to the node occupying that column.
    private var slots: [Int: SKNode] = [:]
    
    /// Creates a wall layer.
    ///
    /// - parameter brickSize: The size of the bricks that will be laid out in the layer. 
    /// - parameter withPhysics: If `true` then the bricks will participate in the physics simulation.
    /// - parameter inverted: If `true`, then the bricks will be flipped vertically.
    init(brickSize: CGSize, withPhysics: Bool, inverted: Bool) {
        self.brickSize = brickSize
        self.withPhysics = withPhysics
        self.inverted = inverted
        super.init()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// Positions wall tiles within the given rect, reusing old ones as needed similar to the way `UITableViewCell` reuse works.
    func render(in rect: CGRect) {
        let currentSlots = Set(slots.keys)
        let newSlots = slotsFor(rect: rect)
        let slotsToRemove = currentSlots.subtracting(newSlots)
        for slot in slotsToRemove {
            let node = slots[slot]!
            node.position = CGPoint(x: -5000, y: -5000)
            slots.removeValue(forKey: slot)
            reuseQueue.append(node)
        }
        let slotsToAdd = newSlots.subtracting(currentSlots)
        for slot in slotsToAdd {
            let node: SKNode = reuseQueue.popLast() ?? {
                let node = WallNode.make(brickSize: brickSize, withPhysics: withPhysics)
                addChild(node)
                return node
            }()
            slots[slot] = node
            node.position = self.position(forSlot: slot)
            if inverted {
                node.zRotation = .pi
            }
        }
    }
    
    func slotsFor(rect: CGRect) -> Set<Int> {
        let firstSlot = Int(floor(rect.minX / brickSize.width))
        let numSlots = Int(ceil(rect.width / brickSize.width))
        return Set((firstSlot..<firstSlot+numSlots+1).map{$0})
    }
    
    func position(forSlot slot: Int) -> CGPoint {
        return CGPoint(x: CGFloat(slot) * brickSize.width + brickSize.width/2, y: frame.size.height/2)
    }
}

