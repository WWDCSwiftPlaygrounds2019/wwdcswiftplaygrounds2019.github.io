import CoreGraphics

/// Represents a column that could contain a hole in the map.
public struct Column {
    
    /// This is set if there is a hole in this column or `nil` if none.
    public var hole: Hole?
}

