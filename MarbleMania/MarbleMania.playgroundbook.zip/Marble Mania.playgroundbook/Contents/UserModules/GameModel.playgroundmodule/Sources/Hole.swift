import CoreGraphics

/// Represents a hole in the map that the marble could fall in to.
public struct Hole {
    
    /// Offset from the left edge of the map node.
    public var x: CGFloat
    
    /// Offset from center of map node.
    public var yOffset: CGFloat
}
