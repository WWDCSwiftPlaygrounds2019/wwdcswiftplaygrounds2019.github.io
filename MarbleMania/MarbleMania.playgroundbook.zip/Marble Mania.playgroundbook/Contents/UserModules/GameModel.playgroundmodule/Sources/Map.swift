import CoreGraphics

/// Represents a map of columns that calculate where holes should go as column indices are requested. It remembers the results.
public struct Map {
    
    /// Initializes a map structure.
    public init(holeDiameter: CGFloat = 120) {
        holeSize = CGSize(width: holeDiameter, height: holeDiameter)
    }
    
    /// The size of the holes.
    public let holeSize: CGSize
    
    /// The columns are considered `holeSize.width` wide. The holes are positioned within the columns based on the requested height.
    /// The higher the column number, the more probable it will have a hole.
    public private(set) var columns: [Column] = []
    
    /// The value to add to the probability that we should add a hole
    public let probabilityIncreaseAtEachNewColumn: CGFloat = 0.01
    
    /// Returns a set of all the column indexes that would be present in the given rect.
    public func columnIndexes(in rect: CGRect) -> Set<Int> {
        let firstSlot = Int(floor(rect.minX / holeSize.width))
        let numSlots = Int(ceil(rect.width / holeSize.width))
        return Set((firstSlot..<firstSlot+numSlots+1).map{$0})
    }
    
    /// Returns the `Column` at the given index, potentially creating one with the given height if it doesn't already exist yet.
    public mutating func getColumn(at index: Int, currentHeight: CGFloat) -> Column {
        ensureThereAreEnoughColumns(upTo: index, currentHeight: currentHeight)
        return columns[index]
    }
    
    /// Returns all columns (and their indexes) that would be visible in the given rect.
    public mutating func getColumns(in rect: CGRect) -> [(index: Int, column: Column)] {
        let indexes = columnIndexes(in: rect)
        return indexes.sorted().map { index in
            (index, getColumn(at: index, currentHeight: rect.height))
        }
    }
    
    /// Returns the column x position at the given index.
    public func columnXPosition(at index: Int) -> CGFloat {
        return CGFloat(index) * holeSize.width
    }
    
    /// Internal method that will ensure there are enough columns calculated to satisfy requests up to the given index, using the `currentHeight` for creating new columns with potential holes.
    private mutating func ensureThereAreEnoughColumns(upTo index: Int, currentHeight: CGFloat) {
        guard index >= columns.count else { return }
        for i in columns.count...index {
            columns.append(makeNewColumn(at: i, height: currentHeight))
        }
    }
    
    /// Internal method that returns a column intended to be positioned at the given `index` and positions any hole within the given `height`.
    private func makeNewColumn(at index: Int, height: CGFloat) -> Column {
        // Don't calculate any holes before this column
        let firstColumn = 20
        guard index >= firstColumn else { return Column(hole: nil) }
        let holeProbability = probabilityIncreaseAtEachNewColumn * CGFloat(index - firstColumn)
        guard CGFloat.random(in: 0..<1000) < holeProbability * 1000 else { return Column(hole: nil) }
        let x = columnXPosition(at: index)
        let y = (height/2) - CGFloat.random(in: 0...height)
        let hole = Hole(x: x, yOffset: y)
        return Column(hole: hole)
    }
}
