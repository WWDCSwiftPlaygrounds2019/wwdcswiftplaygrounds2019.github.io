public enum GameState {
    case active
    case ended
    
    public var isRunning: Bool {
        switch self {
        case .active: return true
        case .ended: return false
        }
    }
}
