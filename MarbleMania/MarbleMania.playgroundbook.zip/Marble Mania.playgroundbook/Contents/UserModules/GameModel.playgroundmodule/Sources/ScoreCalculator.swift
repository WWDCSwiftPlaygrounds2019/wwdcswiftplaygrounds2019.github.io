import Foundation
import CoreGraphics

/// Takes in the current distance and time and calculates the score for the player.
public struct ScoreCalculator {
    
    /// The score most recently calculated.
    public private(set) var currentScore: Int
    
    /// Score is tracked internally as a floating point value to be able to remember increments leading up to integer values
    private var scoreBacking: CGFloat
    
    /// The last distance seen when asked to calculate.
    private var lastDistance: CGFloat
    
    /// The last time seen when asked to calculate.
    private var lastTime: TimeInterval
    
    /// Creates an empty `ScoreCalculator` value.
    public init() {
        currentScore = 0
        scoreBacking = 0
        lastDistance = 0
        lastTime = 0
    }
    
    /// Updates the current score based on the given distance and time (which must be monotonically increasing or the call is a noop).
    /// This returns the calculated score as a convenience.
    @discardableResult public mutating func updateScore(withDistance distance: CGFloat, time: TimeInterval) -> Int {
        guard distance > lastDistance && time > lastTime else { return currentScore }
        scoreBacking += (distance - lastDistance) / (CGFloat(time - lastTime) * 9000)
        lastDistance = distance
        lastTime = time
        currentScore = Int(floor(scoreBacking))
        return currentScore
    }
}
