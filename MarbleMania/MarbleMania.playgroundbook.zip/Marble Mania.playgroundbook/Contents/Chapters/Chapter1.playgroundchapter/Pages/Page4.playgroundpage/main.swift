import CoreGraphics

let rect = CGRect(x: 5000, y: 0, width: 150, height: 150)
let map = Map(holeDiameter: 20)
let node = MapNode(map: map)
node.preview(rect: rect)
