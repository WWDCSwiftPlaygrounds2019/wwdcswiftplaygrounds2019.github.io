import CoreMotion
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let manager = CMMotionManager()
manager.startAccelerometerUpdates()

func repeatEvery(_ seconds: TimeInterval, _ work: @escaping () -> ()) {
    work()
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
        repeatEvery(seconds, work)
    }
}

repeatEvery(0.5) {
    guard let acceleration = manager.accelerometerData?.acceleration else { return }
    acceleration.x
}
