import SpriteKit
import PlaygroundSupport
import CoreMotion

PlaygroundPage.current.needsIndefiniteExecution = true

let manager = CMMotionManager()
manager.startAccelerometerUpdates()

class Stage: SKView {
    public override func layoutSubviews() {
        super.layoutSubviews()
        scene?.size = bounds.size
    }
}

class Dot: SKShapeNode {
    static func makeDot() -> Dot {
        let dot = Dot(circleOfRadius: 20)
        dot.position = CGPoint(x: 100, y: 150)
        dot.fillColor = .red
        let body = SKPhysicsBody(circleOfRadius: 20)
        body.restitution = 0.5
        body.affectedByGravity = false
        body.mass = 0.3
        dot.physicsBody = body
        return dot
    }
}

class BallScene: SKScene {
    var dots: [Dot] = []
    
    @objc func addDot() {
        let dot = Dot.makeDot()
        dot.position = CGPoint(x: size.width/2, y: size.height/2)
        dots.append(dot)
        addChild(dot)
    }
    
    override func update(_ currentTime: TimeInterval) {
        guard let acceleration = manager.accelerometerData?.acceleration else { return }
        let multiplier: CGFloat = 600
        let gravity = CGVector(dx: -CGFloat(acceleration.y) * multiplier,
                               dy: CGFloat(acceleration.x) * multiplier)
        for dot in dots {
            dot.physicsBody?.applyForce(gravity)
        }
    }
    
    public override func didFinishUpdate() {
        let maxValue: CGFloat = 800
        for dot in dots {
            dot.physicsBody?.velocity.clamp(absoluteValueOf: maxValue)
        }
    }
    
    public override func didChangeSize(_ oldSize: CGSize) {
        let edge = SKPhysicsBody(edgeLoopFrom: CGRect(origin: .zero, size: size))
        physicsBody = edge
    }
}

let stage = Stage(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
let scene = BallScene(size: CGSize(width: 300, height: 300))

PlaygroundPage.current.liveView = stage
stage.presentScene(scene)

scene.addDot()

let tap = UITapGestureRecognizer(target: scene, action: #selector(scene.addDot))
stage.addGestureRecognizer(tap)
